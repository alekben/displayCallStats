
1. [Overview](#overview)
2. [Development Setup (Manual)](#develop)
3. [Install Development With setup.sh](#install_dev)
4. [Binary Release Creation](#binary_create)
5. [Installing A Binary Release](#binary_install)
6. [Usage](#usage)

## Overview <a name="overview"></a>
This project extends the NGINX RTMP module, enabling it to publish RTMP audio and video directly into an Agora channel using the Agora Linux SDK. 
We refer to this product as the RTMP Gateway or RTMPG. It is has been well used in production by some customers with OBS and Vmix. It supports Dual Stream such that a single RTMP stream can result in a low and high quality stream available on Agora.

For more information on the NGINX RTMP module see 
      https://www.nginx.com/blog/video-streaming-for-remote-learning-with-nginx/
      
      
## Development Setup (Manual) <a name="develop"></a>
This section can be performed with a single script [see next section](#install_dev)
The following steps assume you are using Ubuntu and have been verified with Ubuntu 18.04 on an AWS t3.medium instance where the publication of a single RTMP stream consumed less than 10% of one CPU core. 

<b>It is also possible to perform all of the steps below using ./server_side_custom_video_source/setup.sh after cloning this repo. </b>

(1) install the required libs

      $ sudo apt update
      $ sudo apt install build-essential git libpcre3 libpcre3-dev zlib1g zlib1g-dev libssl-dev unzip libcurl4-openssl-dev
      $ sudo apt install libavcodec-dev libavformat-dev libavutil-dev libswscale-dev libx264-dev nasm libavfilter-dev libopus-dev 

(2) create a directory to build the custom NGINX in

      $ mkdir custom-ngnix

(3) clone this current repo into the directory

(4) get a recent copy of the Agora Linux SDk (Nov 2020 onwards) and unzip it into the directory

(5) clone the nginx and nginx-rtmp-module repos into the directory

      $ git clone https://github.com/arut/nginx-rtmp-module.git
      $ git clone https://github.com/nginx/nginx.git 

   now, you should have the following dir structure
   + /custom-ngnix
      + nginx
      + server_side_custom_video_source
      + nginx-rtmp-module
      + agora_rtc_sdk

(6) install Agora C wrapper library and AgoraSDK

      $ cd ~/server_side_custom_video_source/libagorac
      $ sudo ./install.sh /home/ubuntu/custom-ngnix/agora_rtc_sdk
      $ cd ..

(7) copy ngx_agora_helper.c and  ngx_agora_helper.h to nginx-rtmp-module

      $ cp ngx_agora_helper.c  ../nginx-rtmp-module/
      $ cp ngx_agora_helper.h  ../nginx-rtmp-module/
   
(8) copy nginx and nginx-rtmp-module patches

      $ cp patches/nginx.patch ../nginx
      $ cp patches/nginx-rtmp-module.patch ../nginx-rtmp-module/

(9) apply the patches 

      $ cd ../nginx
      $ patch -f -p 1 < nginx.patch
      $ cd ../nginx-rtmp-module/
      $ patch -f -p 1 < nginx-rtmp-module.patch
      $ cd ../nginx

(10) compile and install

      $ ./auto/configure --add-module=../nginx-rtmp-module 
      $ make 
      $ sudo make install
   
(11) configure

      $ sudo vi /usr/local/nginx/conf/nginx.conf
      
      # add the following block to the NGINX config file (above the http block is fine)
      rtmp {
          server {
              listen 1935;
              application live {
                      live on;
                      interleave on;
                      record all;
                      record_path /tmp/rec;
              }
          }
      }

      To enable media log: add this line to the config:
      error_log logs/error.log debug;
      
      $ sudo mkdir /tmp/rec; sudo chmod 777 /tmp/rec;
   
(12) run

      $ sudo /home/ubuntu/custom-ngnix/nginx/objs/nginx;  

The NGINX recording module will now convert an inbound RTMP bitstream and send the audio and video to Agora

No recordings will be written to disk but it was still necessary to create the folder /tmp/rec and give it read/write permission

### Install Development With Setup.sh <a name="install_dev"></a>

setup.sh will perform all of the above as follows.    
After cloning this repo into your current folder:    

      $ cd server_side_custom_video_source
      $ sudo ./setup.sh /path/to/the/current/folder /path/to/build/at 

      Example:
      $ sudo ./setup.sh /home/ubuntu/server_side_custom_video_source /home/ubuntu
      
      This will copy server_side_custom_video_source under custom-ngnix also for local dev
      
      To only build /usr/local/lib/libagorac.so during development       
      $ cd /home/ubuntu/custom-ngnix/server_side_custom_video_source/libagorac
      $ sudo ./install.sh /home/ubuntu/custom-ngnix/agora_rtc_sdk
      
      To only build /home/ubuntu/custom-ngnix/nginx/objs/nginx during development   
      $ cd /home/ubuntu/custom-ngnix/nginx
      $ ./auto/configure --add-module=../nginx-rtmp-module 
      $ make

      To kill & run:   
      $ sudo killall nginx; sleep 5; sudo /home/ubuntu/custom-ngnix/nginx/objs/nginx 
      
      

## Binary Release Creation <a name="binary_create"></a>

Build a binary distribution package by following these steps:

      $ cd /your/dir/to/server_side_custom_video_source
      $ sudo ./build.sh

This will create dist-agora-rtmp.tar.gz which you can use to install the RTMPG on another server.   
Commit the above to this repo and the binary will be available here.    
wget https://github.com/AgoraIO-Solutions/server_side_custom_video_source/raw/master/release/dist-agora-rtmp.tar.gz     
The install instructions below expect to find the binary on public URL so copy there also.       

## Installing A Binary Release <a name="binary_install"></a>

  (1) Download dist-agora-rtmp.tar.gz from public URL to the destination server
  
      $ cd /home/ubuntu
      $ wget https://sa-utils.agora.io/dist-agora-rtmp-ubuntu22.04.tar.gz
      
       
  (2) extract the package

      $ tar -xvzf dist-agora-rtmp-ubuntu22.04.tar.gz
      $ cd dist-agora-rtmp

  (3) backup any current release and install package

      $ sudo ./install.sh

 This will install the required libraries and the RTMPG server.   
 It will also add a crontab entry to start the RTMPG on future reboots.   
 It will save the previous release to ngnix-bk-xx, where xx is the installation date.    
 You can recover that later with the following:

  (4) recover prevous installation

      $ ./recover.sh /path/to/backup/dir

## Usage <a name="Usage"></a>

Publishing RTMP

      Method 1:  Specifiy Agora App ID or token in the RTMP URI:
      Set the RTMP URI to rtmp://server_ip:1935/live?appid=APP_ID_OR_TOKEN&channel=CHANNEL&uid=USER_ID&abr=50000
      
      appid can contain either the Agora App Id or an Agora Authentication Token
      
      channel is the Agora channel name

      uid is the agora user id (optional)
      
      abr is the 'audio bitrate' in bits/second. You should use 50000 for voice applications and 250000 for high definition music

      enc is the switch to enable (&enc=1) or disable (&enc=0) media encryption (optional)

      If media encryption is enabled, on your server add a file /usr/local/nginx/conf/nginx_agora_appid_.txt. This file should have Agrora App Id and the encryption key. Currently only SM4_128_ECB is supported.

      sample nginx_agora_appid_.txt: Add appID in the first line and encryption key in the 2nd line.
      402xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      12345ABCDx

      Method 2: specify a configuration id in the RTMP URI, no appid is necessary, other parameters the same as in Method 1
      Set the RTMP URI to rtmp://server_ip:1935/live?configid=CONFIGID&channel=CHANNEL&uid=USER_ID&abr=50000
      
      configid is an number or string to identify the Agora project information you stored on the server
      On your server, add a file /usr/local/nginx/conf/nginx_agora_appid_CONFIGID.txt and Agora project info. This file should have Agora App Id and the certificate. If your project does not have certificate enable, put "0" to indicate it. If media encryption is enabled, the encryption key should also be stored in this file. (see samples below)

      channel is the Agora channel name

      uid is the agora user id (optional)

      abr is the 'audio bitrate' in bits/second. You should use 50000 for voice applications and 250000 for high definition music

      enc is the switch to enable (&enc=1) or disable (&enc=0) media encryption (optional)
      To enable media encryption, in th file /usr/local/nginx/conf/nginx_agora_appid_CONFIGID.txt. After Agrora App Id and the certificate, add encryption key. Currently only SM4_128_ECB is supported.

      Sample 1: rtmp://server_ip:1935/live?configid=0&channel=CHANNEL&uid=USER_ID&abr=50000

      in /usr/local/nginx/conf/nginx_agora_appid_0.txt, put Agora App ID in the first line, and certificate in the second line:
      402xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      4cexxxxxxxxxxxxxxxxxxxxxxxxxxxxx

      or if you did not enable certificate for your project, add a "0" in the second line.
      402xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      0

      Sample 2: rtmp://server_ip:1935/live?configid=abc&channel=CHANNEL&uid=USER_ID&abr=50000&enc=1
      in /usr/local/nginx/conf/nginx_agora_appid_abc.txt, put Agora App ID in the first line, and certificate in the second line, encryption key in the third line:
      402xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      4cexxxxxxxxxxxxxxxxxxxxxxxxxxxxx
      12345ABCDx

Using OBS

     In Settings > Stream set the Service to Custom and the Server to the RTMP URI described above
     
     In Settings > Output set the Keyframe Interval to be 4s and the Profile to be baseline.
     

You can now start streaming from OBS into Agora

You can view the stream inside Agora using the simple web demo here and setting the relevant appId and channel
https://agoraio-community.github.io/AgoraWebSDK-NG/demo/basicVideoCall/index.html

RTMPG Test plan

Run a call for 1 hour on a t3.medium and monitor the CPU and Memory usage

The call should enable dual stream and can use appid e.g

appid=AAAAA&channel=CCCCCCC&uid=777&abr=150000&dual=true&dfps=24&dvbr=500000&dwidth=640&dheight=360

This will generate high and low streams

Check for lip sync (use a YouTube sync video) and publish this from OBS.
https://www.youtube.com/watch?v=xKYd4vFwdA8

Monitor low stream here
https://sa-utils.agora.io/statsaudiencelow/

You can share the following usage instructions with customers:
https://tinyurl.com/rtmp2agora     
     
     
## Config Files

     /usr/local/nginx/conf/nginx.conf
     /usr/local/nginx/conf/rtmpg.conf
     
## Stream Key Rest API

    In the config set REST API such as      
    stream-key-rest-api=https://ps3cqwsagkthu3yqarzpyez5ru0gzcen.lambda-url.us-east-1.on.aws      
    
      RTMPG will  connect to details returned e.g.     
      {"uid":"444","appid":"abcdef","cid":"ben","token":"20b7c51ff4c644ab80cf5a4e646b0537"}

      as returned from here:        
      https://ps3cqwsagkthu3yqarzpyez5ru0gzcen.lambda-url.us-east-1.on.aws/?streamkey=bob

      
   
## Limit HD
If the config "limit-hd" in /usr/local/nginx/conf/rtmpg.conf is set to "yes" then RTMP streams published with a width greater than limit-hd-width will be reduced (transcoded) to a stream with the properties set with these configurations


limit-hd=no

limit-hd-width=1280
limit-hd-height=720
limit-hd-bitrate=1600000
limit-hd-fps=30
     
## Logging 

     Log level is set in /usr/local/nginx/conf/nginx.conf
     default is 
     error_log logs/error.log notice;
     Can change notice to debug and then restart with 
     sudo /home/ubuntu/custom-ngnix/nginx/objs/nginx -s stop;  sudo /home/ubuntu/custom-ngnix/nginx/objs/nginx 
     log files are in /usr/local/nginx/logs for nginx logs and /tmp for agora SDK and RTMPG logs
     
     Log rolling:
     
     
