#include <stdbool.h>
#include <fstream>
#include <atomic>
#include "agorac.h"

#include <string>
#include <cstring>
#include <iostream>
#include <fstream>

#include <condition_variable>
#include <chrono>

//agora header files
#include "NGIAgoraRtcConnection.h"
#include "IAgoraService.h"
#include "AgoraBase.h"

#include "helpers/agoradecoder.h"
#include "helpers/agoraencoder.h"
#include "helpers/agoralog.h"
#include "helpers/localconfig.h"

#include "helpers/context.h"

#include "helpers/utilities.h"
#include "agoratype.h"
#include "helpers/agoraconstants.h"
#include "mediathreads.h"
#include "restapi/restapi.h"

#include "media/videolimit.h"

#include "RtcTokenBuilder.h"
using namespace agora::tools;

void UpdatePredictedFps(agora_context_t* ctx, const long& timestamp);

//do not use it before calling agora_init
void agora_log(agora_context_t* ctx, const char* message){
   ctx->log_func(ctx->log_ctx, message);
}

//helper function for creating a service
agora::base::IAgoraService* createAndInitAgoraService(bool enableAudioDevice,
                                                      bool enableAudioProcessor,
						      bool enableVideo,
						      bool stringUserid,
						      bool enableEncryption, const char* appid) {
  auto service = createAgoraService();
  agora::base::AgoraServiceConfiguration scfg;
  scfg.enableAudioProcessor = enableAudioProcessor;
  scfg.enableAudioDevice = enableAudioDevice;
  scfg.enableVideo = enableVideo;
  scfg.useStringUid=stringUserid;
  if (enableEncryption) {
    scfg.appId = appid;
  }

  int ret = service->initialize(scfg);
  return (ret == agora::ERR_OK) ? service : nullptr;
}

void SetThreadPriority(const std::shared_ptr<std::thread>& thrd){
  sched_param sch_params;
  sch_params.sched_priority =sched_get_priority_max(SCHED_RR);
  if(pthread_setschedparam(thrd->native_handle(), SCHED_RR, &sch_params)) {
       logMessage("Error: failed to set video thread priority: "+std::string(std::strerror(errno)));
   } else {
       logMessage("PASS: set video thread priority!");
   }
}

std::atomic<unsigned long> stream_id={};
#define ENC_KEY_LENGTH        128
agora_context_t*  agora_init(char* in_app_id, char* in_config_id, char* in_ch_id, char* in_user_id, bool enable_enc,
		                         bool is_dual_set_in_url, short enable_dual, unsigned int  dual_vbr, 
			                       unsigned short  dual_width, unsigned short  dual_height,
                             unsigned short min_video_jb, unsigned short dfps,
                             unsigned short no_video_jb,
                             const char* streamkey){

  
  int32_t buildNum = 0;
  getAgoraSdkVersion(&buildNum);
  logMessage("**** Agora SDK version: "+std::to_string(buildNum)+" ****");

  //rotate log file if necessary
  CheckAndRollLogFile();

  std::string config_id(in_config_id);
  std::string app_id(in_app_id);
  std::string chanel_id=(in_ch_id);
  std::string user_id(in_user_id);
  std::string proj_appid = "abcd";

  agora_context_t* ctx=new agora_context_t;

  //create and load local configs
  const std::string rtmpgConfigFileName="/usr/local/nginx/conf/rtmpg.conf";
  ctx->callConfig=std::make_shared<LocalConfig>();
  ctx->callConfig->loadConfig(rtmpgConfigFileName);
  ctx->callConfig->print();

  ctx->transcodeHighVideo=false;
  ctx->isLimitingHDOn=false;
  ctx->isLimitTpOn=false;

  //read  agora params from restAPI, if rest api key is available 
  if(ctx->callConfig->hasRestApiKey())
  {
     std::string streamKeyFullUrl=ctx->callConfig->getStreamRestApiKey()+"?streamkey="+streamkey; 
     if(RestApi::GetStreamingParamFromRestApi(streamKeyFullUrl))
     {
          if(RestApi::hasAppId())
          {
            app_id=RestApi::appid;
          }
          //note how token overwrite appid
          if(RestApi::hasToken())
          {
            app_id=RestApi::token;
          }
          if(RestApi::hasCid())
          {
            chanel_id=RestApi::cid;
          }
          if(RestApi::hasUid())
          {
            user_id=RestApi::uid;
          }
     }
  }

  char encryptionKey[ENC_KEY_LENGTH] = "";
  std::string filename = "/usr/local/nginx/conf/nginx_agora_appid_";
  std::ifstream inf;
  std::string temp_str;
  std::string certificate;
  uint32_t equal_or_not;
  uint32_t expiration_time_in_seconds = 60*60*24; //24 hour: 60x60 seconds
  uint32_t curr_time_stamp = time(NULL);
  uint32_t privilegeExpiredTs= curr_time_stamp + expiration_time_in_seconds;
  std::string agoraToken;

  //set configuration
  ctx->config.clientRoleType = agora::rtc::CLIENT_ROLE_BROADCASTER;
  ctx->config.channelProfile = agora::CHANNEL_PROFILE_LIVE_BROADCASTING;
  ctx->config.autoSubscribeAudio = false;
  ctx->config.autoSubscribeVideo = false;

  ctx->enable_dual=enable_dual;
  
  if(is_dual_set_in_url==false)
  {
    ctx->enable_dual=ctx->callConfig->isDualEnabled();
    logMessage("enable_dual BW " + ctx->enable_dual);
    dual_width=ctx->callConfig->getDualWidth();
    dual_height=ctx->callConfig->getDualHeight();
    dual_vbr=ctx->callConfig->getDualVBR();
    dfps=ctx->callConfig->getDualFPS();
  }

  ctx->disable_jb=(min_video_jb==0);

  ctx->jb_size=ctx->callConfig->getInitialJbSize();
  if(ctx->disable_jb){
     ctx->jb_size=0;
  }

  ctx->currentJBMax=ctx->callConfig->getMaxJbSize();
  ctx->jbMin=(long)(ctx->currentJBMax/2.0);

  equal_or_not = strcmp(config_id.c_str(), "NULL");
  if ((equal_or_not != 0) || enable_enc) {
    if (equal_or_not != 0)
      filename =filename.append(config_id);
    filename =filename.append(".txt");
    logMessage("file to open: " + filename);
    inf.open(filename, std::ifstream::in);
    if(!inf.is_open()){
      logMessage("agora Failed to open AppId, certificate and/or key for encryption!");
      return NULL;
    }

    getline(inf, proj_appid);
    //logMessage("appid: " + proj_appid);
    getline(inf, certificate);
    //logMessage("cert: " + certificate);
    if (enable_enc) {
      getline(inf, temp_str);
      //logMessage(temp_str.c_str());
      int str_leng = temp_str.copy(encryptionKey, temp_str.length());
      encryptionKey[str_leng] = '\0';
    }
    inf.close();
  }


  // Create Agora service
  if(user_id=="" ||  isNumber(user_id)){
      logMessage("numeric  user id: "+ user_id);
      ctx->service = createAndInitAgoraService(false, true, true,  false, enable_enc, proj_appid.c_str());
      if (equal_or_not != 0 && (strcmp(certificate.c_str(), "0")!=0)) {
        agoraToken = RtcTokenBuilder::buildTokenWithUid(
        proj_appid.c_str(), certificate, in_ch_id, stoi(user_id), UserRole::Role_Publisher,
        privilegeExpiredTs);
        logMessage("Token With Int Uid:" + agoraToken);
      }
  }
  else{
     logMessage("string user id: "+ user_id);
     ctx->service = createAndInitAgoraService(false, true, true,  true, enable_enc, proj_appid.c_str());
     if (equal_or_not != 0 && (strcmp(certificate.c_str(), "0")!=0)) {
       agoraToken = RtcTokenBuilder::buildTokenWithUserAccount(
       proj_appid.c_str(), certificate.c_str(), in_ch_id, user_id.c_str(), UserRole::Role_Publisher,
       privilegeExpiredTs);
      logMessage("Token With string Uid:" + agoraToken);
      }
  }

  //create audio encoder
  ctx->audioEncoderPtr.reset(new AudioEncoder());

  if (!ctx->service) {
    delete ctx;
    return NULL;
  }

  ctx->connection =ctx->service->createRtcConnection(ctx->config);
  if (!ctx->connection) {
     delete ctx;
     return NULL;
  }

  // open the encryption mode
  // QC change
  if ( ctx->connection && enable_enc) {
    agora::rtc::EncryptionConfig Config;
    Config.encryptionMode = agora::rtc::SM4_128_ECB;  //currently only this mode is supported
    Config.encryptionKey = encryptionKey;

    if (ctx->connection->enableEncryption(true, Config) < 0) {
      logMessage("agora Failed to enable Encryption!");
      delete ctx;
      return NULL;
    } else {
      logMessage("agora built-in encryption enabled!");
    }
  }

  //register network connection, if required in config
  if(ctx->callConfig->printUplinkNetworkInfo()){
    ctx->connectionObserver = std::make_shared<ConnectionObserver>();
    ctx->connection->registerObserver(ctx->connectionObserver.get());
    ctx->connection->registerNetworkObserver(ctx->connectionObserver.get());
  }
  
  // Connect to Agora channel
  if (equal_or_not !=0) {
    if (strcmp(certificate.c_str(), "0")!=0) {
      if(ctx->connection->connect(agoraToken.c_str(), chanel_id.c_str(), user_id.c_str())){
        delete ctx;
        return NULL;
      }
    } else {
      if(ctx->connection->connect(proj_appid.c_str(), chanel_id.c_str(), user_id.c_str())){
        delete ctx;
        return NULL;
      }
    }
  } else {
    if(ctx->connection->connect(app_id.c_str(), chanel_id.c_str(), user_id.c_str())){
      delete ctx;
      return NULL;
    }
  }

  // Create media node factory
  auto factory = ctx->service->createMediaNodeFactory();
  if (!factory) {
    return NULL;
  }


  //audio
  // Create audio data sender
  ctx->audioSender = factory->createAudioEncodedFrameSender();
  if (!ctx->audioSender) {
    return NULL;
  }

  // Create audio track
  ctx->audioTrack =ctx->service->createCustomAudioTrack(ctx->audioSender, agora::base::MIX_DISABLED);
  if (!ctx->audioTrack) {
    return NULL;
  }

  // Create video frame sender
  ctx->videoSender = factory->createVideoEncodedImageSender();
  if (!ctx->videoSender) {
    return NULL;
  }


  // Create video track
  #if SDK_BUILD_NUM>=190534 
   agora::rtc::SenderOptions options; 
   options.ccMode = agora::rtc::TCcMode::CC_ENABLED;
  #else
  agora::base::SenderOptions options;
  options.ccMode=agora::base::CC_ENABLED;  //for send_dual_h264
  #endif
  ctx->videoTrack =ctx->service->createCustomVideoTrack(ctx->videoSender,options);
  if (!ctx->videoTrack) {
    return NULL;
  }

  // Set the dual_model
  agora::rtc::SimulcastStreamConfig Low_streamConfig;
  //ctx->videoTrack->enableSimulcastStream(true, Low_streamConfig);
  ctx->videoTrack->setSimulcastStreamMode(agora::rtc::SIMULCAST_STREAM_MODE::ENABLE_SIMULCAST_STREAM, Low_streamConfig);


  // Publish audio & video track
  ctx->connection->getLocalUser()->publishAudio(ctx->audioTrack);
  ctx->connection->getLocalUser()->publishVideo(ctx->videoTrack);

  ctx->isConnected=1;
  
  ctx->videoJB=std::make_shared<WorkQueue <Work_ptr> >();
  ctx->audioJB=std::make_shared<WorkQueue <Work_ptr> >();

  ctx->encodeNextFrame=true;
  ctx->fps=0;
  ctx->lastFpsPrintTime=Now();
  ctx->lastBufferingTime=Now();
  ctx->reBufferingCount=0;
  ctx->lastFrameTimestamp=0; 
  ctx->timestampPerSecond=0;
  ctx->predictedFps=30;
  ctx->lastHighFrameSendTime=Now();
  ctx->lastLowFrameSendTime=Now();
  ctx->timeZeroVideo=Now();
  ctx->timeZeroAudio=Now();
  ctx->callStart=Now();
  ctx->isJbBuffering=false;
  ctx->isLimitingHD=false;
  ctx->isLimitingHDPass=false;
  ctx->lastVideoTimestamp=0;
  ctx->lastAudioTimestamp=0;
  ctx->highVideoFrameCount=0;
  ctx->lowVideoFrameCount=0;
  ctx->limitedHighVideoFrameCount=0;
  ctx->lastVideoSampingInterval=1000/(float)ctx->predictedFps;
  ctx->dfps=dfps;

  ctx->noVideoJb=no_video_jb;

  ctx->audioDumpFileName="/tmp/rtmp_agora_audio_"+std::to_string((long)(ctx))+std::to_string(++stream_id)+".raw";

  ctx->isRunning=true;
  //start thread handlers
  //no_video_jb=false;
  if(no_video_jb){
       ctx->videoThreadHigh=std::make_shared<std::thread>(&VideoThreadHandlerHighNoJB,ctx);
       ctx->audioThread=std::make_shared<std::thread>(&AudioThreadHandlerNoJB,ctx);
  }
  else{
       ctx->videoThreadHigh=std::make_shared<std::thread>(&VideoThreadHandlerHigh,ctx);
       //SetThreadPriority(ctx->videoThreadHigh);
       ctx->audioThread=std::make_shared<std::thread>(&AudioThreadHandler,ctx);
       //SetThreadPriority(ctx->audioThread);
  }

  //TODO: this need adjusting the operating system to support setting the priority
  //sudo vi /etc/security/limits.conf
  //and set:
  // <username> hard rtprio 99
  //<username> soft  rtprio 99
  //then reboot for your changes to take place


  //as we will limit high video dynamically, we will need to create encoder/dcoder any way
      
  //create video encoder/decoder
  ctx->videoDecoder=std::make_shared<AgoraDecoder>();
  if(!ctx->videoDecoder->init()){
      return NULL;
  }

  if (ctx->enable_dual) 
  {
    ctx->videoEncoder=std::make_shared<AgoraEncoder>(dual_width,dual_height,dual_vbr, dfps);
    ctx->videoEncoder->setQMin(ctx->callConfig->getQMin());
    ctx->videoEncoder->setQMax(ctx->callConfig->getQMax());

    if(! ctx->videoEncoder->init())
    {
      return NULL;
    }
  } 

  //create a thread for low video
  ctx->videoQueueLow=std::make_shared<WorkQueue <Work_ptr> >();
  ctx->videoThreadLow=std::make_shared<std::thread>(&VideoThreadHandlerLow,ctx);
  
  return ctx;
}

void PruneJb(agora_context_t* ctx)
{
    constexpr int AUDIO_TIME_PER_FRAME=20; //ms
    //prune audio
    auto elementsToRemove=ctx->audioJB->size()-ctx->currentJBMax/(float)AUDIO_TIME_PER_FRAME;
    ctx->audioJB->prune(elementsToRemove);

    auto lastAudioElement= ctx->audioJB->back();
    auto lastAudioTs=lastAudioElement->timestamp;

    long lastVideoTs=0;

    int removedVideoFrameCount=0;
    while(!ctx->videoJB->isEmpty()) 
    {
        auto lastVideoElement=ctx->videoJB->back();
        lastVideoTs=lastVideoElement->timestamp;
        if(lastAudioTs>lastVideoTs)
        {
            break;
        }
        else
        {
            ctx->videoJB->getBack(); 
            removedVideoFrameCount++;
        }
    }

    logMessage("JB Prune: removed "+std::to_string((int)(elementsToRemove*AUDIO_TIME_PER_FRAME))+" audio ms, and "+
                                   std::to_string(removedVideoFrameCount*ctx->predictedFps)+" video ms"+
                                   ", current audio JB size: "+std::to_string(AUDIO_TIME_PER_FRAME*ctx->audioJB->size())+
                                   ", max size: "+std::to_string(ctx->currentJBMax));
}

int agora_send_video(agora_context_t* ctx,agora_video_frame_ctx_t* frame){

   constexpr int AUDIO_TIME_PER_FRAME=20; //ms

   auto timePerFrame=(1000/(float)ctx->predictedFps);
   Work_ptr work=std::make_shared<Work>(frame->bytes,frame->len, frame->is_key_frame);
   work->timestamp=frame->timestamp;
   
   //check if we need to create an encoder for limit-throughput
   checkAndCreateThroughputEncoder(ctx, frame);

   if(frame->is_key_frame)
   {
      if(((ctx->audioJB->size()*AUDIO_TIME_PER_FRAME)>ctx->currentJBMax*1.3) &&
          ctx->noVideoJb==false)
      {
         if(ctx->callConfig->useDetailedVideoLog())
         {
           logMessage(GetAddressAsString(ctx)+"JB Prune: Audio buffer pruning ( current size: "+std::to_string(ctx->audioJB->size()*AUDIO_TIME_PER_FRAME)+ "ms) on iFrame arriving.");
         }
        
         PruneJb(ctx);
      }

      if(ctx->callConfig->useDetailedVideoLog())
      {
         logMessage(GetAddressAsString(ctx)+"iFrame received");
      }
   }

   ctx->videoJB->add(work);
 
   //update fps based on frame timestamp
   UpdatePredictedFps(ctx, frame->timestamp);
  
   //log current fps
   if(GetTimeDiff(ctx->lastFpsPrintTime, Now())>=1000){
      if(ctx->callConfig->useFpsLog()){
         logMessage(GetAddressAsString(ctx)+"JB-Video: (ms): " +
                           std::to_string((int)(ctx->videoJB->size()*timePerFrame)) +
                            "/"+
                           std::to_string(ctx->jb_size) +
                           ", fps="+std::to_string(ctx->fps)+
                           ", predicted fps="+ std::to_string(ctx->predictedFps));
     }
   }
   return 0; //no errors
}

int agora_send_audio(agora_context_t* ctx, agora_audio_packet_ctx_t* packet){

    
    Work_ptr work=std::make_shared<Work>(packet->bytes,packet->len, 0);
    work->timestamp=packet->timestamp; 
    if(ctx->callConfig->useDetailedAudioLog()){
   	 logMessage(GetAddressAsString(ctx)+" audio frame received "+ std::to_string(packet->timestamp));
    }

    ctx->audioJB->add(work);

    return 0;
}


void agora_disconnect(agora_context_t** ctx){

  logMessage("start agora disonnect ...");

  auto tempCtx=(*ctx);

  tempCtx->isRunning=false;
   //tell the thread that we are finished
    Work_ptr work=std::make_shared<Work>(nullptr,0, false);
    work->is_finished=true;

   tempCtx->videoJB->add(work);
   
   tempCtx->videoQueueLow->clear();
   tempCtx->videoQueueLow->add(work);

   tempCtx->audioJB->add(work);

   //wait for media threads to finish
   //the order of which thread will finish first is not important in this case
   //wait for the 1st media thread to finish
   {
     std::unique_lock<std::mutex> lk(tempCtx->threadFinishMutex);
     tempCtx->threadFinishCondition.wait_for(lk, std::chrono::seconds(2), []{return true;});
   }

   //wait for the 2nd media thread to finish
   {
     std::unique_lock<std::mutex> lk(tempCtx->threadFinishMutex);
     tempCtx->threadFinishCondition.wait_for(lk, std::chrono::seconds(2), []{return true;});
   }

   //wait for the 3rd media thread to finish
   {
     std::unique_lock<std::mutex> lk(tempCtx->threadFinishMutex);
     tempCtx->threadFinishCondition.wait_for(lk,std::chrono::seconds(2), []{return true;});
   }

   //make sure the last thread completely terminated its loop before detaching it
   std::this_thread::sleep_for(std::chrono::milliseconds(10));
   
   tempCtx->connection->getLocalUser()->unpublishAudio(tempCtx->audioTrack);
   tempCtx->connection->getLocalUser()->unpublishVideo(tempCtx->videoTrack);

   bool  isdisconnected=tempCtx->connection->disconnect();
   if(isdisconnected){
      return;
   }

   tempCtx->audioSender = nullptr;
   tempCtx->videoSender = nullptr;
   tempCtx->audioTrack = nullptr;
   tempCtx->videoTrack = nullptr;


   tempCtx->videoJB=nullptr;;
   tempCtx->videoQueueLow=nullptr;
   tempCtx->audioJB=nullptr;;

   //delete context
   tempCtx->connection=nullptr;

   tempCtx->service->release();
   tempCtx->service = nullptr;
  
   tempCtx->videoThreadHigh->detach();
   if(tempCtx->enable_dual){
      tempCtx->videoThreadLow->detach();
   }
   tempCtx->audioThread->detach();

   tempCtx->videoThreadHigh=nullptr;;
   tempCtx->videoThreadLow=nullptr;
   tempCtx->audioThread=nullptr; 

   tempCtx->videoDecoder=nullptr;
   tempCtx->videoEncoder=nullptr;

   tempCtx->highVideoEncoder=nullptr;

   delete (*ctx);

   logMessage("Agora disonnected ");
}

void agora_set_log_function(agora_context_t* ctx, agora_log_func_t f, void* log_ctx){
    ctx->log_func=f;
    ctx->log_ctx=log_ctx;
}

void agora_log_message(agora_context_t* ctx, const char* message){
   if(ctx->callConfig->useDetailedAudioLog()){
      logMessage(std::string(message));
   }
}

void agora_dump_audio_to_file(agora_context_t* ctx, unsigned char* data, short sampleCount)
{
    if(ctx->callConfig->dumpAudioToFile()==false){
       return;
    }

   std::ofstream meidaFile(ctx->audioDumpFileName, std::ios::binary|std::ios::app);	
   meidaFile.write(reinterpret_cast<const char*>(data), sampleCount*sizeof(float)); 
   meidaFile.close();
}

void UpdatePredictedFps(agora_context_t* ctx, const long& timestamp){

constexpr float MaxFps=60.0;
constexpr float MinFps=15.0;


   ctx->fps=ctx->fps+1;

   if(ctx->lastFrameTimestamp!=0){
     auto diff=timestamp-ctx->lastFrameTimestamp;
     ctx->timestampPerSecond +=diff;
   }

   ctx->lastFrameTimestamp=timestamp;

   if(GetTimeDiff(ctx->lastFpsPrintTime, Now())>=1000 ){ // make sure we have had enough frames

      float averageTimeStamp=ctx->timestampPerSecond/((float)ctx->fps);
      
       //safty check when  averageTimeStamp is not correct
       if(averageTimeStamp>1000/MaxFps && 
          GetTimeDiff(ctx->callStart, Now())>=2000 && // 16.666 ms for 60 fps
          1000/averageTimeStamp >= MinFps){ 

              ctx->predictedFps=1000/averageTimeStamp;
       }

     ctx->timestampPerSecond=0;
     ctx->highVideoFrameCount=0;
     ctx->limitedHighVideoFrameCount=0;
     ctx->lowVideoFrameCount=0;
     ctx->lastFpsPrintTime=Now();
     ctx->fps=0;
   }
}
