#ifndef _AGORA_C_H_
#define _AGORA_C_H_
#include <stdbool.h>
#ifdef __cplusplus
 #define EXTERNC extern "C"
 #else
 #define EXTERNC
 #endif

 typedef  struct agora_context_t agora_context_t;
 typedef  void (*agora_log_func_t)(void*, const char*);

 /*holds video frame context*/
 typedef struct 
 {
    int width;
	int height;
	int fps;
	int bitrate;
    
	unsigned char* bytes;
	unsigned long len;
	int is_key_frame;
	long timestamp;
 }
 agora_video_frame_ctx_t;

/*hold audio frame context*/
typedef struct 
 {
    unsigned char* bytes; 
	unsigned long len;
	long timestamp;
 }
 agora_audio_packet_ctx_t;

 EXTERNC agora_context_t*  agora_init(char* app_id, char* config_id, char* ch_id, char* user_id, bool enc_enable,
		                            bool is_dual_set_in_url, short enable_dual, unsigned int  dual_vbr, 
				                    unsigned short  dual_width,  unsigned short  dual_height,
									unsigned short min_video_jb, unsigned short dfps,
									unsigned short no_video_jb, const char* streamkey);

 /*sends one video frame to agora. It just triggers the send, the actual send will happen
 in  another thread*/
 EXTERNC int  agora_send_video(agora_context_t* ctx,  agora_video_frame_ctx_t* frame);

/*sends one audio packet to agora. It just triggers the send, the actual send will happen
 in  another thread*/
 EXTERNC int  agora_send_audio(agora_context_t* ctx, agora_audio_packet_ctx_t* packet);

 EXTERNC void agora_disconnect(agora_context_t** ctx);

 EXTERNC void agora_set_log_function(agora_context_t* ctx, agora_log_func_t f, void* log_ctx);

 EXTERNC void agora_log_message(agora_context_t* ctx, const char* message);

 EXTERNC void agora_dump_audio_to_file(agora_context_t* ctx, unsigned char* data, short sampleCount);

 #undef EXTERNC


#endif
