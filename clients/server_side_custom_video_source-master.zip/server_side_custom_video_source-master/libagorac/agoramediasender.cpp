#include "agoramediasender.h"


#include "IAgoraService.h"
#include "AgoraBase.h"
#include "NGIAgoraMediaNodeFactory.h"
#include "NGIAgoraMediaNode.h"
#include "NGIAgoraVideoTrack.h"
#include "NGIAgoraRtcConnection.h"

#include "helpers/agoraconstants.h"
#include "helpers/agoralog.h"
#include "helpers/localconfig.h"
#include "helpers/context.h"
#include "helpers/utilities.h"
#include "agoratype.h"

#include "helpers/agoradecoder.h"
#include "helpers/agoraencoder.h"

void sendVideoFrameToAgora(agora_context_t* ctx, 
                           const unsigned char* buffer,  
                           unsigned long len,
                           bool isKeyFrame,
                           const agora::rtc::VIDEO_STREAM_TYPE& streamType)
{
  auto frameType=agora::rtc::VIDEO_FRAME_TYPE_DELTA_FRAME; 
  if(isKeyFrame){
     frameType=agora::rtc::VIDEO_FRAME_TYPE_KEY_FRAME;
  }

  agora::rtc::EncodedVideoFrameInfo videoEncodedFrameInfo;
  videoEncodedFrameInfo.rotation = agora::rtc::VIDEO_ORIENTATION_0;
  videoEncodedFrameInfo.codecType = agora::rtc::VIDEO_CODEC_H264;
  videoEncodedFrameInfo.framesPerSecond = 0;
  videoEncodedFrameInfo.captureTimeMs = getAgoraCurrentMonotonicTimeInMs();
  videoEncodedFrameInfo.decodeTimeMs = 0; //videoEncodedFrameInfo.captureTimeMs;
  videoEncodedFrameInfo.frameType = frameType;
  videoEncodedFrameInfo.streamType = streamType;

  ctx->videoSender->sendEncodedVideoImage(buffer,len,videoEncodedFrameInfo);
}

bool doSendLowVideo(agora_context_t* ctx, const unsigned char* buffer,  unsigned long len,int is_key_frame){

  auto frameType=agora::rtc::VIDEO_FRAME_TYPE_DELTA_FRAME;
  if(is_key_frame)
  {
     frameType=agora::rtc::VIDEO_FRAME_TYPE_KEY_FRAME;
  }

  //for transcoding
  const uint32_t MAX_FRAME_SIZE=2*1024*1020; 
  uint32_t outBufferSize=0;
  std::unique_ptr<uint8_t[]> outBuffer(new uint8_t[MAX_FRAME_SIZE]);

  //decode current farme
  auto width=ctx->videoDecoder->decode(buffer, len);
  if(width==0){
     logMessage(GetAddressAsString(ctx)+": unexpected error happend while decoding a video frame!");
     return false;
  }
  auto frame=ctx->videoDecoder->getFrame();
  
  //check if we need to skip some frames
  ctx->encodeNextFrame=false;
  float lowHeighRatio= ctx->predictedFps/(float)ctx->dfps;
  
  if((ctx->lowVideoFrameCount*lowHeighRatio)<ctx->highVideoFrameCount){
      ctx->encodeNextFrame=true;
  }

  if((ctx->enable_dual==true) &&(ctx->encodeNextFrame==true || is_key_frame)){

    //reencode
    ctx->videoEncoder->encode(frame, outBuffer.get(), outBufferSize,is_key_frame);
    sendVideoFrameToAgora(ctx, outBuffer.get(),outBufferSize, is_key_frame, agora::rtc::VIDEO_STREAM_LOW);

    ctx->lowVideoFrameCount++;
  }

  ctx->encodeNextFrame=false;
  if((ctx->limitedHighVideoFrameCount)<=ctx->highVideoFpsLimit){
      ctx->encodeNextFrame=true;
  }

  //send highstream from here so that we make use of same decoder
  if(ctx->transcodeHighVideo==true && (ctx->encodeNextFrame==true || is_key_frame))
  {
    ctx->highVideoEncoder->encode(frame, outBuffer.get(), outBufferSize,is_key_frame);
    sendVideoFrameToAgora(ctx, outBuffer.get(),outBufferSize, is_key_frame, agora::rtc::VIDEO_STREAM_HIGH);
    ctx->limitedHighVideoFrameCount++;
  }

  return true;
}

bool doSendHighVideo(agora_context_t* ctx, const unsigned char* buffer,  unsigned long len,int is_key_frame){

  //we will  send high stream from here if we will  transcode
  if(ctx->transcodeHighVideo==false)
  {
    sendVideoFrameToAgora(ctx, buffer,len, is_key_frame, agora::rtc::VIDEO_STREAM_HIGH);
  }

  return true;
}

bool doSendAudio(agora_context_t* ctx, const unsigned char* buffer,  unsigned long len){

  //encode audio before sending it to agora
  constexpr int  MAX_OUT_BUFFER=1000;
  uint8_t  encodededAudiobytes[MAX_OUT_BUFFER];
  auto encodedLen=ctx->audioEncoderPtr->encode((int16_t*)(buffer),encodededAudiobytes);

  agora::rtc::EncodedAudioFrameInfo audioFrameInfo;
  audioFrameInfo.numberOfChannels =1; //TODO
  audioFrameInfo.sampleRateHz = 48000; //TODO
  audioFrameInfo.captureTimeMs = getAgoraCurrentMonotonicTimeInMs();
  audioFrameInfo.codec = agora::rtc::AUDIO_CODEC_OPUS;
  ctx->audioSender->sendEncodedAudioFrame(encodededAudiobytes,encodedLen, audioFrameInfo);
  return true;
}
