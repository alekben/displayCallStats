#ifndef _AGORA_MEDIA_SENDER_H_
#define _AGORA_MEDIA_SENDER_H_

struct agora_context_t;

bool doSendLowVideo(agora_context_t* ctx, const unsigned char* buffer, 
                          unsigned long len,int is_key_frame);

bool doSendHighVideo(agora_context_t* ctx, const unsigned char* buffer,  
                                 unsigned long len,int is_key_frame);

bool doSendAudio(agora_context_t* ctx, const unsigned char* buffer,  
                                        unsigned long len);




#endif 