#ifndef _AGORA_DECODER_H_
#define _AGORA_DECODER_H_

extern "C" {
  #include "libavcodec/avcodec.h"
  #include "libavutil/mem.h"
}

#include <functional>

using PostDecode_fn=std::function<void(AVFrame*)>;

//decode h264
class AgoraDecoder{
public:

  AgoraDecoder();

  ~AgoraDecoder();

  //initialize the encoder params, should be called before any decoding
  bool init();

  int decode(const uint8_t* in, const uint32_t& inSize);

  AVFrame* getFrame(){return m_avOutFrame;}
  
  void setPostDecodeFn(const PostDecode_fn& f);

protected:

 uint32_t copyDeocodedFrame(AVFrame *frame, uint8_t* buffer);

private:

  AVCodec        *m_avCodec;
  AVCodecContext *m_avContext;

  AVFrame        *m_avOutFrame;
  AVPacket       *m_inputPacket;

  PostDecode_fn  _postDecodeFn;

};

#endif
