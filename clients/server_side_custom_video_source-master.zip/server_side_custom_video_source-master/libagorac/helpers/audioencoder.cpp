#include "audioencoder.h"
#include "agoralog.h"
#include <string.h>

AudioEncoder::AudioEncoder()
{
  int err=0;

  constexpr int channelCount=1;
  constexpr int sampleRate=48000;

  //init opus
  opusEncoder= opus_encoder_create(sampleRate,
		                           channelCount, 
                                   OPUS_APPLICATION_VOIP,
                                   &err);
  if(err<0){
    logMessage("audio encoder cannot be initialized"); 
  }

  /*err = opus_encoder_ctl(opusEncoder, OPUS_SET_BITRATE(ctx->bitrate));
  if(err<0){
     return NULL;
  }*/

   //set FEC
   opus_encoder_ctl(opusEncoder, OPUS_SET_INBAND_FEC(true));
}
AudioEncoder::~AudioEncoder()
{
    opus_encoder_destroy(opusEncoder);
}

int AudioEncoder::encode(int16_t* inBytes, uint8_t* outBytes)
{
    constexpr int  OPUS_SAMPLE_COUNT=960;
    constexpr int  MAX_OUT_BUFFER=1000;

    return opus_encode(opusEncoder,inBytes,OPUS_SAMPLE_COUNT, outBytes, MAX_OUT_BUFFER);
}

int AudioEncoder::encodeSilence(uint8_t* outBytes)
{
    constexpr int  OPUS_SAMPLE_COUNT=960;
    constexpr int  MAX_OUT_BUFFER=1000;

    int16_t inBytes[OPUS_SAMPLE_COUNT];
    memset(inBytes,0,OPUS_SAMPLE_COUNT*sizeof(int16_t));

    return opus_encode(opusEncoder,inBytes,OPUS_SAMPLE_COUNT, outBytes, MAX_OUT_BUFFER);
}
  

