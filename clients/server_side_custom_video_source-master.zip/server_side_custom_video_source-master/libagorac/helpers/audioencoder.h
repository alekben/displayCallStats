#ifndef _AUDIO_ENCODER_H_
#define _AUDIO_ENCODER_H_

#include <opus/opus.h>
#include <string>

class AudioEncoder
{
public:

   AudioEncoder();
   ~AudioEncoder();

   int encode(int16_t* inBytes, uint8_t* outBytes);
   int encodeSilence(uint8_t* outBytes);

private:
   OpusEncoder   *opusEncoder;
};
#endif 