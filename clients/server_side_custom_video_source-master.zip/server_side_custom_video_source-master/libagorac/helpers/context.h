#ifndef _CONTEXT_H_
#define _CONTEXT_H_

#include "../agoratype.h"

#if SDK_BUILD_NUM>=190534 
#include "IAgoraService.h"
#include "NGIAgoraLocalUser.h"
#include "NGIAgoraAudioTrack.h"

#include "NGIAgoraMediaNodeFactory.h"
#include "NGIAgoraMediaNode.h"
#include "NGIAgoraVideoTrack.h"
#include "NGIAgoraRtcConnection.h"
#endif

#include "../observers/connectionobserver.h"

#include "audioencoder.h"

using AgoraVideoSender_ptr=agora::agora_refptr<agora::rtc::IVideoEncodedImageSender>;
using AgoraAudioSender_ptr=agora::agora_refptr<agora::rtc::IAudioEncodedFrameSender>;
using AgoraVideoFrameType=agora::rtc::VIDEO_FRAME_TYPE;
using ConnectionConfig=agora::rtc::RtcConnectionConfiguration;

//a context that group all require info about agora
struct agora_context_t{

  agora::base::IAgoraService*                      service;
  agora::agora_refptr<agora::rtc::IRtcConnection>  connection;

  int                                              isConnected;
  ConnectionConfig                                 config;

  AgoraVideoSender_ptr                             videoSender;
  AgoraAudioSender_ptr                             audioSender;

  std::shared_ptr<std::thread>                    videoThreadHigh;
  std::shared_ptr<std::thread>                    videoThreadLow;

  std::shared_ptr<std::thread>                    audioThread;

  agora::agora_refptr<agora::rtc::ILocalAudioTrack> audioTrack;
  agora::agora_refptr<agora::rtc::ILocalVideoTrack> videoTrack;

  bool                                            isRunning;

  AgoraDecoder_ptr                                videoDecoder;
  AgoraEncoder_ptr                                videoEncoder;

  AgoraEncoder_ptr                                highVideoEncoder;


  bool                                            encodeNextFrame;
  bool                                            enable_dual;
  agora_log_func_t                                log_func;
  void                                            *log_ctx;

  uint8_t                                         fps;
  float                                           predictedFps;

  TimePoint                                       lastFpsPrintTime; 
  TimePoint                                       lastBufferingTime;

  uint16_t                                        jb_size; 
  bool                                            disable_jb;

  LocalConfig_ptr                                 callConfig;

  uint64_t                                        reBufferingCount;    

  long                                            lastFrameTimestamp; 
  long                                            timestampPerSecond; 

  TimePoint                                       lastHighFrameSendTime;
  TimePoint                                       lastLowFrameSendTime;
  TimePoint                                       timeZeroVideo;
  TimePoint                                       callStart;
  TimePoint                                       timeZeroAudio;

   long                                            lastVideoTimestamp;
   long                                            lastAudioTimestamp;

   int                                             lastVideoSampingInterval;

   WorkQueue_ptr                                   videoJB;
   WorkQueue_ptr                                   audioJB;  

   WorkQueue_ptr                                   videoQueueLow;

   bool                                            isJbBuffering;   
   bool                                            isLimitingHD;   
   bool                                            isLimitingHDPass;   

   uint16_t                                        dfps; 

   uint8_t                                         highVideoFrameCount;
   uint8_t                                         lowVideoFrameCount;
   uint8_t                                         limitedHighVideoFrameCount;  

   std::string                                     audioDumpFileName; 

   long                                            currentJBMax;
   long                                            jbMin;  
  
   ConnectionObserver_ptr                          connectionObserver; 

   //signals from media threads when finished to main threads
   std::condition_variable                         threadFinishCondition;
	std::mutex                                      threadFinishMutex; 

   std::unique_ptr<AudioEncoder>                    audioEncoderPtr;  

   bool                                             isAudioBuffering;
   bool                                             shouldPruneJb;
   bool                                             noVideoJb;

   bool                                             transcodeHighVideo;
   uint8_t                                          highVideoFpsLimit;

   bool                                             isLimitingHDOn;
   bool                                             isLimitTpOn;
};

class Work{

public:

   Work(const unsigned char* b, const unsigned long& l, bool is_key):
	buffer(nullptr){
  
       if(b==nullptr){
	       return;
       }

       buffer=new unsigned char[l];
       memcpy(buffer, b, l);

       len=l;
    
       is_key_frame=is_key;
       is_finished=0;
   }

   ~Work(){
     if(buffer==nullptr) return;
     delete [] buffer;
   }

   unsigned char*        buffer;
   unsigned long         len;
   bool                  is_key_frame;

   bool                  is_finished;

   long                  timestamp;
   
};


#endif
