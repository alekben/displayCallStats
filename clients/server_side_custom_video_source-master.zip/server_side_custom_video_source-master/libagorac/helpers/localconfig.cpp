
#include "localconfig.h"
#include "agoralog.h"
#include <algorithm>

#include <mutex>

std::mutex g_config_file_mutex;

LocalConfig::LocalConfig():
_useDetailedVideoLog(false),
_useDetailedAudioLog(false),
_useSpeedupLog(false),
_useFpsLog(false),
_limitHD(false),
_rejectHDPlus(false),
_initialJbSize(120),       //in ms
_maxJbSize(8000),          //in ms
_timeToIncreaseJbSize(15),  //in seconds
_dumpAudioToFile(false),
_qMin(0),
_qMax(0),
_limitWidth(1280),
_limitHeight(720),
_limitBitrate(1600000),
_limitFPS(300),
_printUplinkNetworkInfo(false),
_enableDual(false),
_dwidth(640),
_dheight(360),
_dvbr(500000),
_dfps(15)
{
   _throughput.clear();
}

 bool LocalConfig::loadConfig(const std::string& filePath){

  std::lock_guard<std::mutex> guard(g_config_file_mutex);

  std::ifstream configFile(filePath, std::ios::in);
  if(!configFile.is_open()){
	 logMessage("Not able to open rtmp config file: "+filePath);
     logMessage("Default configs will be used!");
	 return false;
  }

   return readConfig(configFile);
 }

 bool LocalConfig::prepareLine(const std::string& in, std::string& out){
	
  out=in;
  
  //remove comments
  auto ret=out.find("//");
  if(ret!=std::string::npos && 
     (out.find("http://")==std::string::npos &&
       out.find("https://")==std::string::npos)){

	 out=out.substr(0, ret);
  }
  
  return true;
}


 bool LocalConfig::readConfig(std::ifstream& file){

  char buffer[1024];

  std::string key;
  std::string value;

  LimitThroughputConfig currentThroughputRecord;

  while(!file.eof()){
	  
	  file.getline(buffer, 1024);

      std::string line(buffer);
      line.erase(remove_if(line.begin(), line.end(), isspace), line.end());

      prepareLine(line,line);

      //ignore empty lines
      if(line.empty()) continue;

	  if(!getKeyValue(line, key, value)){
		  return false;
	  }

      if(key=="detailed-video-log" && (value=="yes" || value=="true")){
         _useDetailedVideoLog=true;
      }
      else if(key=="detailed-audio-log" && (value=="yes" || value=="true")){
         _useDetailedAudioLog=true;
      }
      else if(key=="fps-log" && (value=="yes" || value=="true")){
         _useFpsLog=true;
      }
      else if(key=="limit-hd" && (value=="yes" || value=="true")){
         _limitHD=true;
      }
      else if(key=="reject-hd-plus" && (value=="yes" || value=="true")){
         _rejectHDPlus=true;
      }
      else if(key=="speedup-log" && (value=="yes" || value=="true")){
         _useSpeedupLog=true;
      }
      else if(key=="jb-initial-size-ms"){
         _initialJbSize=std::atoi(value.c_str());
      }
      else if(key=="jb-max-size-ms"){
         _maxJbSize=std::atoi(value.c_str());
      }
      else if(key=="Jb-max-doubles-if-emptied-within-seconds"){
         _timeToIncreaseJbSize=std::atoi(value.c_str());
      }
      else if(key=="dump-raw-audio-to-file" && (value=="yes" || value=="true")){
         _dumpAudioToFile=true;
      }
      else if(key=="qmin"){
         _qMin=std::atoi(value.c_str());
      }
      else if(key=="qmax"){
         _qMax=std::atoi(value.c_str());
      }  
      else if(key=="limit-hd-width"){
         _limitWidth=std::atoi(value.c_str());
      }  
      else if(key=="limit-hd-height"){
         _limitHeight=std::atoi(value.c_str());
      }  
      else if(key=="limit-hd-bitrate"){
         _limitBitrate=std::atoi(value.c_str());
      }  
      else if(key=="limit-hd-fps"){
         _limitFPS=std::atoi(value.c_str());
      } 
      else if(key=="print-uplink-network-info" && (value=="yes" || value=="true")){
         _printUplinkNetworkInfo=true;
      }
      else if(key=="dual" && value=="yes"){
         _enableDual=true;
      }
      else if(key=="dvbr"){
         _dvbr=std::atoi(value.c_str());
      } 
      else if(key=="dfps"){
         _dfps=std::atoi(value.c_str());
      } 
      else if(key=="dwidth"){
         _dwidth=std::atoi(value.c_str());
      } 
      else if(key=="dheight"){
         _dheight=std::atoi(value.c_str());
      } 
      else if(key=="stream-key-rest-api"){
         _streamRestApiKey=value.c_str();
      } 
      else if(key=="limit-throughput-width"){
         currentThroughputRecord.width=std::atoi(value.c_str());
      }
      else if(key=="limit-throughput-height"){
         currentThroughputRecord.height=std::atoi(value.c_str());
      } 
      else if(key=="limit-throughput-bitrate"){
         currentThroughputRecord.bitrate=std::atoi(value.c_str());
      }
      else if(key=="limit-throughput-fps"){
         currentThroughputRecord.fps=std::atoi(value.c_str());
         _throughput.emplace_back(currentThroughputRecord);
      } 

  }

  //validate user input
  if(_initialJbSize<0 || _initialJbSize>8000){
      _initialJbSize=120;  //default
  }

  return true;
 }

 bool LocalConfig::getKeyValue(const std::string& line,std::string& key, std::string& value){
	
  auto ret=line.find("=");
  if(ret!=std::string::npos){
     key=line.substr(0, ret);
     value=line.substr(ret+1, line.length());
     return true;
  }
	
  return false;
}

 void LocalConfig::print(){
    
   logMessage("Will use the following config for this call: ");

   logMessage("Detailed video log: "+getStringfromBool(_useDetailedVideoLog));
   logMessage("Detailed audio log: "+getStringfromBool(_useDetailedAudioLog));
   logMessage("FPS log: "+getStringfromBool(_useFpsLog));

   logMessage("jb-initial-size-ms: "+std::to_string(_initialJbSize));
   logMessage("jb-max-size-ms: "+std::to_string(_maxJbSize));
   logMessage("Jb-max-doubles-if-emptied-within-seconds: "+std::to_string(_timeToIncreaseJbSize));

   logMessage("print-uplink-network-info: "+getStringfromBool(_printUplinkNetworkInfo));

   logMessage("dual: "+getStringfromBool(_enableDual));

   logMessage("dwidth: "+std::to_string(_dwidth));
   logMessage("dheight: "+std::to_string(_dheight));
   logMessage("dfps: "+std::to_string(_dfps));
   logMessage("dvbr: "+std::to_string(_dvbr));
   logMessage("stream-key-rest-api: "+_streamRestApiKey);
 }

 std::string LocalConfig::getStringfromBool(const bool& flag){
    
    std::string ret=flag==true? "yes": "no";

    return ret;
 }

 const std::list<LimitThroughputConfig>& LocalConfig::getThroughputConfig()
 {
    return _throughput;
 }
