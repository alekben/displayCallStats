#ifndef _LOCAL_CONFIG_H_
#define _LOCAL_CONFIG_H_

#include <string>
#include <fstream>
#include <list>

//holds info about when to start transcoding
//for example, when we have:
//limit-throughput-width=1280
//limit-throughput-height=720
//limit-throughput-bitrate=1600000
//limit-throughput-fps=30
//This means transcode to these settings if high stream is 1280 x 720 and either FPS > 30 or Bitrate > 1600000
struct LimitThroughputConfig
{
    uint32_t width;
    uint32_t height;
    uint32_t bitrate;
    uint8_t  fps;
};

class LocalConfig{

 public:

  LocalConfig();

  bool     loadConfig(const std::string& filePath);

  bool     useDetailedVideoLog(){return _useDetailedVideoLog;}
  bool     useDetailedAudioLog(){return _useDetailedAudioLog;}
  bool     useFpsLog(){return _useFpsLog;}

  bool     limitHD(){return _limitHD;}
  int      limitWidth(){return _limitWidth;}
  int      limitHeight(){return _limitHeight;}
  int      limitBitrate(){return _limitBitrate;}
  int      limitFPS(){return _limitFPS;}

  bool     rejectHDPlus(){return _rejectHDPlus;}

  bool     useSpeedupLog(){return _useSpeedupLog;}

  uint16_t  getInitialJbSize(){return _initialJbSize;}
  uint16_t  getMaxJbSize(){return _maxJbSize;}
  uint16_t  getTimeToIncreaseJbSize(){return _timeToIncreaseJbSize;}

  bool      dumpAudioToFile(){return _dumpAudioToFile;}

  int       getQMin(){return _qMin;}
  int       getQMax(){return _qMax;}

  void print();

  bool printUplinkNetworkInfo(){return _printUplinkNetworkInfo;}

  bool isDualEnabled(){return _enableDual;}
  int getDualWidth(){return _dwidth;}
  int getDualHeight() {return _dheight;}
  int getDualVBR(){return _dvbr;}
  int getDualFPS(){return _dfps;}

  std::string getStreamRestApiKey() {return _streamRestApiKey;}
  bool hasRestApiKey(){return _streamRestApiKey!="";}

  const std::list<LimitThroughputConfig>& getThroughputConfig();

protected:

  bool getKeyValue(const std::string& line,std::string& key, std::string& value);
  bool readConfig(std::ifstream& file);

  std::string getStringfromBool(const bool& flag);
  bool prepareLine(const std::string& in, std::string& out);

 private:

  bool       _useDetailedVideoLog;
  bool       _useDetailedAudioLog;
  bool       _useSpeedupLog;
  bool       _useFpsLog;

  bool       _limitHD;

  int        _limitWidth;
  int        _limitHeight;
  int        _limitBitrate;
  int        _limitFPS;

  bool       _rejectHDPlus;
  uint16_t   _initialJbSize;
  uint16_t   _maxJbSize;
  uint16_t   _timeToIncreaseJbSize;
  bool       _dumpAudioToFile;

  int        _qMin;
  int        _qMax;

  bool       _printUplinkNetworkInfo;

  bool       _enableDual;
  int        _dwidth;
  int        _dheight; 
  int        _dvbr; 
  int        _dfps; 

  std::string _streamRestApiKey;

  std::list<LimitThroughputConfig> _throughput;
};

#endif
