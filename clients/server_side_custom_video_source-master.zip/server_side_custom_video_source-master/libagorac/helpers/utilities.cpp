#include "utilities.h"
#include "NGIAgoraRtcConnection.h"
#include "IAgoraService.h"
#include "AgoraBase.h"

#include "agoradecoder.h"
#include "agoraencoder.h"
#include "agoralog.h"
#include "localconfig.h"

#include "agoraconstants.h"

#include "../agoramediasender.h"


//#include "../userobserver.h"
#include "context.h"

TimePoint Now(){
   return std::chrono::steady_clock::now();
}

long GetTimeDiff(const TimePoint& start, const TimePoint& end){
  return std::chrono::duration_cast<std::chrono::milliseconds>(end-start).count();
}

std::string GetAddressAsString(agora_context_t* ctx){
   return std::to_string((long)(ctx))+": ";
}

void ResizeBuffer(agora_context_t* ctx){

   const uint8_t MAX_REBUFFERING_COUNT=1;  

   //double JB size if the buffer  keeps running out to frquently
   auto diffBufferingTime=GetTimeDiff(ctx->lastBufferingTime, Now());
   if(ctx->reBufferingCount>=MAX_REBUFFERING_COUNT &&   //just ignore the first buffering, which might not be real
        diffBufferingTime<ctx->callConfig->getTimeToIncreaseJbSize()*1000){

        //double the buffer size
        ctx->jb_size = ctx->jb_size*2;
        
        //update max and min buffer size 
        ctx->currentJBMax=ctx->jb_size;
        ctx->jbMin=(long)(ctx->currentJBMax/2.0);

        logMessage(GetAddressAsString(ctx)+"Video-JB: JB size increased to "+
             std::to_string(ctx->jb_size)+", because it runs out too frequently");
     }

     ctx->lastBufferingTime=Now();
     ctx->reBufferingCount++;
}

bool isNumber(const std::string& userIdString)
{
    return !userIdString.empty() && std::find_if(userIdString.begin(), userIdString.end(), [](unsigned char ch)
		    { return !std::isdigit(ch); }) == userIdString.end();
}

int getVideoSyncBytesPos(const uint8_t* buffer){
	
  if(buffer[0] !=0) return 0;
  if(buffer[1] !=0) return 0;
  if(buffer[2] ==1) return 3;

  if(buffer[2] !=0) return 0;

  if(buffer[3] ==1) return 4;
	
  return 0;
}


