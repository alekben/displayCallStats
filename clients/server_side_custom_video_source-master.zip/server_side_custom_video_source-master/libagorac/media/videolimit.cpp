#include "videolimit.h"

#include "../helpers/agoradecoder.h"
#include "../helpers/agoraencoder.h"
#include "../helpers/agoralog.h"
#include "../helpers/localconfig.h"

#include "NGIAgoraRtcConnection.h"
#include "IAgoraService.h"
#include "AgoraBase.h"

#include "../helpers/agoraconstants.h"
#include "../helpers/utilities.h"
#include "../helpers/context.h"

#include "../agoramediasender.h"

void enableTranscoding(agora_context_t* ctx, const std::string& reason)
{
   if(ctx->transcodeHighVideo==false)
   {
      ctx->transcodeHighVideo=true;
      logMessage(GetAddressAsString(ctx)+": limit-throughput: transcoding high stream has been turned on, reason: "+reason);
   }
}

void disableTranscoding(agora_context_t* ctx, const std::string& reason)
{
   if(ctx->transcodeHighVideo==true)
   {
      ctx->transcodeHighVideo=false;
      ctx->highVideoFpsLimit=0;
      logMessage(GetAddressAsString(ctx)+": limit-throughput: transcoding high stream has been turned off, reason: "+reason);
   }
}

void createAndInitEncoder(agora_context_t* ctx, const uint32_t& width, const uint32_t& height,
                      const int& bitrate, const int& fps)
{
   ctx->highVideoEncoder=std::make_shared<AgoraEncoder>(width,height,bitrate, fps);

   ctx->highVideoEncoder->setQMin(ctx->callConfig->getQMin());
   ctx->highVideoEncoder->setQMax(ctx->callConfig->getQMax());

   if(!ctx->highVideoEncoder->init()){
      logMessage(GetAddressAsString(ctx)+": limit-throughput: cannot init video encoder for: "+
            std::to_string(width)+"x"+std::to_string(height));
   }
   else
   {
      logMessage(GetAddressAsString(ctx)+": limit-throughput: an encoder has been created for: "+            
            std::to_string(width)+"x"+std::to_string(height)+ "BR (bps): "+std::to_string(bitrate)+
            ", fps: "+std::to_string(fps));
   }

   //check if the decoder has not yet been created, create it at this point
   if(ctx->videoDecoder==nullptr)
   {
      ctx->videoDecoder=std::make_shared<AgoraDecoder>();
      if(! ctx->videoDecoder->init())
      {
         logMessage(GetAddressAsString(ctx)+": limit-throughput: failed to create a video decoder");
      }
      else
      {
         logMessage(GetAddressAsString(ctx)+": limit-throughput: video decoder has not been yet created. We create it at this point "+            
            std::to_string(width)+"x"+std::to_string(height));
      }
   }
}

void checkAndCreateThroughputEncoder(agora_context_t* ctx, agora_video_frame_ctx_t* frame)
{
   //update transcoding in case of limitHD (first priority over limit tp)
   if (ctx->callConfig->limitHD())
   {
      ctx->highVideoFpsLimit=ctx->callConfig->limitFPS();
      if(frame->width > ctx->callConfig->limitWidth()) 
      {
         enableTranscoding(ctx, "limitHD");
         if(ctx->highVideoEncoder==nullptr)
         {
            createAndInitEncoder(ctx, ctx->callConfig->limitWidth(),ctx->callConfig->limitHeight(),
                     ctx->callConfig->limitBitrate(),ctx->callConfig->limitFPS());
         }

         ctx->highVideoFpsLimit=ctx->callConfig->limitFPS();
         ctx->isLimitingHDOn=true;
      }
      else if(ctx->isLimitTpOn==false)
      {
         disableTranscoding(ctx, "limitHD");
         ctx->isLimitingHDOn=false;
      }
   }

   //check for tp limit (second priority)
   /*
     example of the logic for enabling throughput limit
     consider the following example in config:

     limit-throughput-width=1280
     limit-throughput-height=720
     limit-throughput-bitrate=1600000
     limit-throughput-fps=30

     This means if high stream is 1280 x 720 and either FPS > 30 or Bitrate > 1600000 then transcode to these settings
   */

   if(ctx->isLimitingHDOn==false)
   {
      /*logMessage(GetAddressAsString(ctx)+": limit-throughput: Receiving: "+
            std::to_string(frame->width)+"x"+std::to_string(frame->height)+", BR (kbps): "+std::to_string(frame->bitrate)+
            ", FPS: "+std::to_string(frame->fps));*/

      bool transcode=false;
      auto throughputConfig=ctx->callConfig->getThroughputConfig();
      for (const auto& configRecord: throughputConfig)
      {
         if((configRecord.width==frame->width && configRecord.height==frame->height)
            && (frame->fps>configRecord.fps || 1000*frame->bitrate>configRecord.bitrate))
         {
            /*logMessage(GetAddressAsString(ctx)+": limit-throughput: TP will limited for: "+
            std::to_string(frame->width)+"x"+std::to_string(frame->height)+", BR (kbps): "+std::to_string(frame->bitrate)+
            ", FPS: "+std::to_string(frame->fps));*/
            if(ctx->highVideoEncoder==nullptr)
            {
               createAndInitEncoder(ctx,configRecord.width, configRecord.height,configRecord.bitrate, configRecord.fps);
            }

            transcode=true;
            ctx->highVideoFpsLimit=configRecord.fps;

            break;
         }
      }

      //check if any of the above configs triggered transcoding
      if(transcode==true)
      {
         enableTranscoding(ctx, "limit-throughput");
         ctx->isLimitTpOn=true;
      }
      else
      {
         disableTranscoding(ctx, "limit-throughput");
         ctx->isLimitTpOn=false;
      }
   }
}

