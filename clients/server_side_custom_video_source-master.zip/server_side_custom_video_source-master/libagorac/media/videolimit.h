#ifndef __VIDEO_LIMIT__H_
#define __VIDEO_LIMIT__H_

#include "../agoratype.h"
#include "../agorac.h"

//check if ThroughputEncoder is created or not. It will create it when
//applicable 
void checkAndCreateThroughputEncoder(agora_context_t* ctx, agora_video_frame_ctx_t* frame);

#endif