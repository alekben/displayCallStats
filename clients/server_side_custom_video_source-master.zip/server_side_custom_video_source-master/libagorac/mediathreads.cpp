#include "mediathreads.h"
#include "agoramediasender.h"

#include "NGIAgoraLocalUser.h"
#include "NGIAgoraAudioTrack.h"

#include "helpers/agoralog.h"
#include "helpers/localconfig.h"
#include "helpers/context.h"
#include "helpers/utilities.h"
#include "agoratype.h"

#include "helpers/agoradecoder.h"
#include "helpers/agoraencoder.h"


constexpr int  AUDIO_TIME_PER_FRAME=20; //ms in the average
constexpr int  VIDEO_TIME_PER_FRAME=30; //ms in the average

bool decodeVideoFrame(agora_context_t* ctx, const Work_ptr& work)
{
    //if the decoder is not null, then decode it
    if(ctx->videoDecoder!=nullptr)
    {
        auto width=ctx->videoDecoder->decode(work->buffer, work->len);
        if(width<0)
        {
            logMessage("decodeVideoFrame: failed to decode a video frame");
            return false;
        }

        auto frame=ctx->videoDecoder->getFrame();

        //if dual is enabled, we add this decoded frame to the low queue
        if(ctx->enable_dual==true)
        {
           //Work_ptr decodedFrameWork=std::make_shared<Work>(frame->bytes,frame->len, frame->is_key_frame);
           //decodedFrameWork->timestamp=work->timestamp;
        }

        return true;
    }

    return false;
}

void VideoThreadHandlerHighNoJB(agora_context_t* ctx){

   while(ctx->isRunning==true){

     //wait untill work is available
     ctx->videoJB->waitForWork();	  
     Work_ptr work=ctx->videoJB->get();
     if(work==NULL) continue;
     if(work->is_finished==1){
	      break;
     }

     if(ctx->enable_dual){
         ctx->videoQueueLow->add(work);
     }

     auto delta=GetTimeDiff(ctx->lastHighFrameSendTime, Now());
     ctx->lastHighFrameSendTime=Now();
     ctx->lastVideoTimestamp=work->timestamp;
     ctx->highVideoFrameCount++;

     if(ctx->callConfig->useDetailedVideoLog()){
     	logMessage("No JB High video timestamp: "+std::to_string(work->timestamp)+", delta: "+std::to_string(delta)+", len: "+std::to_string(work->len));
     }
     doSendHighVideo(ctx,work->buffer, work->len, (bool)(work->is_key_frame));
  }

}

void VideoThreadHandlerHigh(agora_context_t* ctx)
{
   constexpr int MIN_VIDEO_SLEEPTIME=10; //ms
   constexpr int ALLOWED_VIDEO_AUDIO_DIFF=10; //in ms

   while(ctx->isRunning==true){

        ctx->videoJB->waitForWork();	  
        Work_ptr work=ctx->videoJB->top();

        if(work==nullptr){
            continue;
        } 
    
        if(work->is_finished) 
        {
            break;
        }

        auto nextVideoTs=work->timestamp;
        if(nextVideoTs-ALLOWED_VIDEO_AUDIO_DIFF<ctx->lastAudioTimestamp)
        {
            work=ctx->videoJB->get();

            doSendHighVideo(ctx,work->buffer, work->len, (bool)(work->is_key_frame));
            ctx->videoQueueLow->add(work);

            if(ctx->callConfig->useDetailedVideoLog()){
     	        logMessage("->Video Sending: ts: "+std::to_string(work->timestamp)+ ", len: "+std::to_string(work->len)+
                           ", last audio ts: "+std::to_string(ctx->lastAudioTimestamp)+
                           ", JB size: "+std::to_string(ctx->predictedFps*ctx->videoJB->size())+" ms");
            }
            ctx->highVideoFrameCount++;
            ctx->lastVideoTimestamp=work->timestamp;
        }
        
        TimePoint  nextSample=Now()+std::chrono::milliseconds(MIN_VIDEO_SLEEPTIME);
        std::this_thread::sleep_until(nextSample);
    }

  //send a signal to main thread, it will be waiting for it
  std::lock_guard<std::mutex> lk(ctx->threadFinishMutex);
  ctx->threadFinishCondition.notify_one();

  logMessage("VideoThreadHandlerHigh ended");
}

void VideoThreadHandlerLow(agora_context_t* ctx){

   while(ctx->isRunning==true){
 
     //wait untill work is available
     ctx->videoQueueLow->waitForWork();
     Work_ptr work=ctx->videoQueueLow->get();

     if(work==NULL) continue;

     if(work->is_finished==1){
        break;
     }

    if (ctx->isLimitingHDPass)  {
        break;
     }

    doSendLowVideo(ctx,work->buffer, work->len, (bool)(work->is_key_frame));
    auto delta=GetTimeDiff(ctx->lastLowFrameSendTime, Now());
    ctx->lastLowFrameSendTime=Now();

  }

  //send a signal to main thread, it will be waiting for it
  std::lock_guard<std::mutex> lk(ctx->threadFinishMutex);
  ctx->threadFinishCondition.notify_one();

  logMessage("VideoThreadHandlerLow ended");
}

TimePoint GetNextSamplingPoint(agora_context_t* ctx)
{
    //calculate the next ts to wait
    auto currentTs=ctx->lastAudioTimestamp;
    auto nextframe=ctx->audioJB->top();
    // no next in queue - thread sleep time would be zero - wont happen for audio
    auto nextTs=(nextframe==nullptr)? currentTs: nextframe->timestamp;

    auto threadsleepTime=nextTs-currentTs;

    const long MaxTimestampDiff=30; // sensible audio packet max delta
    if(threadsleepTime>MaxTimestampDiff){ 

    	logMessage(GetAddressAsString(ctx)+" AUDIO SLEEP MaxTimestampDiff "+std::to_string(MaxTimestampDiff)+" threadsleepTime "+std::to_string(threadsleepTime)+
                   ", audio JB size: "+std::to_string(ctx->audioJB->size()*AUDIO_TIME_PER_FRAME));
        threadsleepTime=MaxTimestampDiff;
    }

    TimePoint nextSample=Now()+std::chrono::milliseconds(threadsleepTime);
    
    return nextSample;
}

bool CheckAudioBuffering(agora_context_t* ctx)
{
    bool isBuffering=false;

    constexpr int AUDIO_JB_MIN_SIZE=2;
    constexpr int AUDIO_JB_MAX_SIZE=1000;

    if(!ctx->isAudioBuffering &&
       ctx->audioJB->size()<AUDIO_JB_MIN_SIZE)
    {
        ctx->isAudioBuffering=true;
        ResizeBuffer(ctx);
    }
    else if(ctx->isAudioBuffering && 
           (ctx->audioJB->size()*AUDIO_TIME_PER_FRAME)>ctx->jb_size)
    {
        ctx->isAudioBuffering=false;
        logMessage("Audio: -----------finished buffering---------- ");
    }

    return ctx->isAudioBuffering;
}

void SendSilentAudio(agora_context_t* ctx)
{
    constexpr int  OPUS_SAMPLE_COUNT=960;
    int16_t silenceAudio[OPUS_SAMPLE_COUNT];
    memset(silenceAudio,0,OPUS_SAMPLE_COUNT*sizeof(int16_t));

    doSendAudio(ctx,(uint8_t*)(silenceAudio), OPUS_SAMPLE_COUNT*sizeof(int16_t));
    if(ctx->callConfig->useDetailedAudioLog())
    {
        logMessage("Audio buffering ..., sending silence, JB size: "+
          std::to_string(AUDIO_TIME_PER_FRAME*ctx->audioJB->size())+"/"+std::to_string(ctx->jb_size) +" ms");
    }
}

bool SendNoneSilentAudio(agora_context_t* ctx)
{
    bool shouldFinish=false;

    //wait until work is available
    ctx->audioJB->waitForWork();
    Work_ptr work=ctx->audioJB->get();
    if(work==NULL) {
     	logMessage("Audio: No Work continue");
	    return shouldFinish;
    }

    if(work->is_finished){
        shouldFinish=true;
        return shouldFinish;
    }

    doSendAudio(ctx,work->buffer, work->len);
    ctx->lastAudioTimestamp=work->timestamp;

    //update the logging 
    if(ctx->callConfig->useDetailedAudioLog())
    {
        logMessage("Audio Sending:  ts: "+std::to_string(work->timestamp)+ 
                   ", len: "+std::to_string(work->len)+
                   ", JB size: "+std::to_string(AUDIO_TIME_PER_FRAME*ctx->audioJB->size())+" ms");
    }

    return shouldFinish;
}

//AudioThreadHandler sends audio to agora every fixed amount of time
void AudioThreadHandler(agora_context_t* ctx)
{
  TimePoint  nextSample=Now();
  bool shouldFinishSending=false;

  while(ctx->isRunning==true){

    //because we send silent audio, adaptive sleep makes sense also
    //in case of buffering
    nextSample +=std::chrono::milliseconds(AUDIO_TIME_PER_FRAME);

    CheckAudioBuffering(ctx);
    if(ctx->isAudioBuffering)
    {
        SendSilentAudio(ctx);
    }
    else
    {
        shouldFinishSending=SendNoneSilentAudio(ctx);
    }

    if(shouldFinishSending)
    {
       break;
    }
     
    std::this_thread::sleep_until(nextSample);
  }

  //send a signal to main thread, it will be waiting for it
  std::lock_guard<std::mutex> lk(ctx->threadFinishMutex);
  ctx->threadFinishCondition.notify_one();
}

void AudioThreadHandlerNoJB(agora_context_t* ctx){

   while(ctx->isRunning==true){
     //wait untill work is available
     ctx->audioJB->waitForWork();
     Work_ptr work=ctx->audioJB->get();
     if(work==NULL) {
     	     logMessage("Audio: No Work continue");
	     continue;
     }

     if(work->is_finished){
        return;
     }

     doSendAudio(ctx,work->buffer, work->len);
     ctx->lastAudioTimestamp=work->timestamp;
    if(ctx->callConfig->useDetailedAudioLog()){
    	 logMessage("NO JB Audio:  current TS: "+std::to_string(work->timestamp)+ ", len: "+std::to_string(work->len));
    }
  }
}
