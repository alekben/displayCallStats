#ifndef _MEDIA_THREADS_H_
#define _MEDIA_THREADS_H_

struct agora_context_t;

//threads
void VideoThreadHandlerHigh(agora_context_t* ctx);
void VideoThreadHandlerHighNoJB(agora_context_t* ctx);
void VideoThreadHandlerLow(agora_context_t* ctx);
void AudioThreadHandler(agora_context_t* ctx);
void AudioThreadHandlerNoJB(agora_context_t* ctx);

#endif 