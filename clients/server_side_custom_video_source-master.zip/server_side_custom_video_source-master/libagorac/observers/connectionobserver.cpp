

#include "connectionobserver.h"
#include "AgoraBase.h"

#include "iostream"

#include "../AccessToken.h"
#include "../helpers/agoralog.h"

void ConnectionObserver::onConnected(const agora::rtc::TConnectionInfo &connectionInfo,
										   agora::rtc::CONNECTION_CHANGED_REASON_TYPE reason)
{
    logMessage("onConnected: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())+
                       ", reason "+std::to_string(reason));

	// notify the thread which is waiting for the SDK to be connected
	connect_ready_.Set();
}

void ConnectionObserver::onDisconnected(const agora::rtc::TConnectionInfo &connectionInfo,
											  agora::rtc::CONNECTION_CHANGED_REASON_TYPE reason)
{
	logMessage("onDisconnected: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())+
                       ", reason "+std::to_string(reason));

	// notify the thread which is waiting for the SDK to be disconnected
	disconnect_ready_.Set();
}

void ConnectionObserver::onConnecting(const agora::rtc::TConnectionInfo &connectionInfo,
											agora::rtc::CONNECTION_CHANGED_REASON_TYPE reason)
{
	logMessage("onConnecting: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())+
                       ", reason "+std::to_string(reason));
}

void ConnectionObserver::onReconnecting(const agora::rtc::TConnectionInfo &connectionInfo,
											  agora::rtc::CONNECTION_CHANGED_REASON_TYPE reason)
{
	logMessage("onReconnecting: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())+
                       ", reason "+std::to_string(reason));

}

void ConnectionObserver::onReconnected(const agora::rtc::TConnectionInfo &connectionInfo,
											 agora::rtc::CONNECTION_CHANGED_REASON_TYPE reason)
{
	logMessage("onReconnected: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())+
                       ", reason "+std::to_string(reason));
}

void ConnectionObserver::onConnectionLost(const agora::rtc::TConnectionInfo &connectionInfo)
{
	logMessage("onConnectionLost: id "+std::to_string(connectionInfo.id)+
                       ", channelId "+std::string(connectionInfo.channelId.get()->c_str()) +
                       ", localUserId "+std::string(connectionInfo.localUserId.get()->c_str())
                       );
}

void ConnectionObserver::onUplinkNetworkInfoUpdated(const agora::rtc::UplinkNetworkInfo &info)
{
    logMessage("***UplinkNetworkInfo (target bitrate bps)***: "+std::to_string(info.video_encoder_target_bitrate_bps));
    
}

void ConnectionObserver::onTokenPrivilegeWillExpire(const char* token)
{
    std::string agoraToken;
    logMessage("Current token will expire in 30 seconds");
    //agoraToken = AccessToken::Build();
    //agora_rtc_connect.renewToken(agoraToken.c_str());

}

void ConnectionObserver::onUserJoined(agora::user_id_t userId)
{
    logMessage("onUserJoined: userId "+std::string(userId));
}

void ConnectionObserver::onUserLeft(agora::user_id_t userId,
										  agora::rtc::USER_OFFLINE_REASON_TYPE reason)
{
   logMessage("onUserLeft: userId "+std::string(userId));
}
