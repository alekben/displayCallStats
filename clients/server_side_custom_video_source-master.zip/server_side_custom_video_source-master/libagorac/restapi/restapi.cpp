#include "restapi.h"

#include "../helpers/agoralog.h"

#include <sstream>
#include <algorithm>
#include <vector>

#include <curl/curl.h>

static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    ((std::string*)userp)->append((char*)contents, size * nmemb);
    return size * nmemb;
}

bool RestApi::GetStreamingParamFromRestApi(const std::string& url)
{
  bool retCode=true;

  CURL *curl;
  CURLcode res;
  std::string responseBuffer;

  curl = curl_easy_init();
  int timeoutForCurl=5000;  //in ms
  if(curl) {
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);

    //we should not block forever
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, timeoutForCurl);
    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    logMessage ("RestAPI Reader: url: "+url);
    logMessage ("RestAPI Reader response: "+responseBuffer);

    std::string jsonValue=responseBuffer;
    prepareJsonString(jsonValue);

    if(!parseJson(jsonValue))
    {
        retCode=false;
    }
  }
  else
  {
    retCode=false;
  }
    
  return retCode;
}

void RestApi::prepareJsonString(std::string& json)
{
   std::vector<char> charToRemove{'}','{','\"'};
   for(const auto& ch: charToRemove)
   {
       json.erase (std::remove(json.begin(), json.end(), ch), json.end());
   }
}
bool RestApi::parseJson(const std::string& json)
{
    bool retCode=true;

    std::string jsonField{""};
    std::stringstream jsonStream(json);

    std::string key(""), value("");

    while(getline(jsonStream, jsonField, ','))
    {
        if(!getKeyValueFromString(jsonField,key, value))
        {
           retCode=false;
        }

        setValueFromKey(key, value);

        logMessage ("RestAPI Reader: key:"+key+", value: "+value);
    }

   return retCode;
}

bool RestApi::getKeyValueFromString(const std::string& str, std::string& key,std::string& value)
{
    bool retCode=false;
    char seprator=':';

    auto pos=str.find(seprator);
    if(pos!=std::string::npos)
    {
        key=str.substr(0,pos);
        value=str.substr(pos+1, str.length());
        
        retCode=true;
    }

    return retCode;
}

 std::string RestApi::uid("");
 std::string RestApi::appid("");
 std::string RestApi::cid("");
 std::string RestApi::token("");

void RestApi::setValueFromKey(const std::string& key, const std::string& value)
{
    if(key=="uid")
    {
        uid=value;
    }
    else if(key=="appid")
    {
        appid=value;
    }
    else if(key=="cid")
    {
        cid=value;
    }
    else if(key=="token")
    {
        token=value;
    }
    else
    {
        logMessage ("RestAPI Reader: invalid key: "+key);
    }
}
