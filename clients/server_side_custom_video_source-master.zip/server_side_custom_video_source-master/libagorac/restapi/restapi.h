#ifndef _REST_API_H_
#define _REST_API_H_

#include <string>

class RestApi
{
   public:
       
          RestApi()=delete;
     
          //receive and parse streaming params from restAPi
          //uid, appid, cid and token
          //return true, if the call is successfull and false otherwise
          static bool GetStreamingParamFromRestApi(const std::string& key);

          static bool hasUid(){return uid!="";}
          static bool hasAppId(){return appid!="";}
          static bool hasCid(){return cid!="";}
          static bool hasToken(){return token!="";}

   protected: 
          //parse json and store tokens
          static bool parseJson(const std::string& json);
          
          //prepere json string by removing not needed characters during the parse
          static void prepareJsonString(std::string& json);

          static bool getKeyValueFromString(const std::string& str, std::string& key,std::string& value);

          //check the key and set the value to one of member variables
          static void setValueFromKey(const std::string& key, const std::string& value);
   public:

          static std::string   uid;
          static std::string   appid;
          static std::string   cid;
          static std::string   token;
};

#endif 
