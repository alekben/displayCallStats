#!/bin/sh
  
# this package installs a binary distribution of agora rtmp module

#install required libraries
sudo apt update
sudo apt install -y libpcre3 libpcre3-dev zlib1g zlib1g-dev libssl-dev unzip
sudo apt install -y libavcodec-dev libavformat-dev libavutil-dev libswscale-dev libx264-dev nasm libavfilter-dev libopus-dev

sudo apt install -y libcurl4-openssl-dev dpkg

sudo killall nginx

NGNIX_DIR="/usr/local/nginx"
if [ -d "$NGNIX_DIR" ];
then
    if [ ! -d ~/backups ];
    then
            mkdir ~/backups
    fi

    backup_dir=~/backups"/ngnix-bk-$(date +'%m-%d-%Y')"
    echo backing up previous installation of ngnix to $backup_dir 

    #delete previous backup  directory if there is any with same name
    if [ ! -d $backup_dir ];
    then
        mkdir $backup_dir
        cp /usr/bin/nginx $backup_dir
        cp $NGNIX_DIR/conf/rtmpg.conf $backup_dir
        cp /usr/local/lib/libagorac.so $backup_dir
        cp /usr/local/lib/libagora_rtc_sdk.so $backup_dir
    fi
fi

#install binary files
dpkg -i package/bin/agora-rtmp-stream.deb

#configure binray files
sudo ldconfig

#create and copy nginx configs
sudo mkdir -p /usr/local/nginx/logs/
sudo cp -r package/bin/conf /usr/local/nginx/

#cp log rotate script to nginx dir
sudo cp package/logrotate.sh /usr/local/nginx/

if [ -d "/usr/local/nginx/logs/nginx.pid" ]; then
  sudo /usr/bin/nginx -s stop; 
fi

sudo /usr/bin/nginx;
echo "@reboot   /usr/bin/nginx;\n0 1 * * Sun   /usr/local/nginx/logrotate.sh;"  | sudo crontab -

