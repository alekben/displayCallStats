#!/bin/sh
sudo mv /usr/local/nginx/logs/error.log /usr/local/nginx/logs/error.log.0
sudo pkill -USR1 nginx
sleep 1
